#include <Inventor/Win/SoWin.h>
#include <Inventor/Win/viewers/SoWinExaminerViewer.h>
#include <Inventor/nodes/SoSeparator.h>
#include <Inventor/nodes/SoCube.h>
#include <Inventor/nodes/SoCone.h>

#include "windows.h"

#include "event/SoOpenTrackerSource.h"
#include "event/SoTrackedArtifactKit.h"
#include "event/SoTrakEngine.h"

int main(int argc, char* argv[])
{
	HWND myWindow = SoWin::init(argv[0]); // pass the app name
	if (myWindow == NULL) exit(1);
	SoSeparator *root = new SoSeparator;
	root->ref();

	// create OT interface node
    SoOpenTrackerSource::initClass();
	SoTrakEngine::initClass();
    SoTrackedArtifactKit::initClass();

    SoOpenTrackerSource *otSource=new SoOpenTrackerSource;
    otSource->ref();
    otSource->configuration="testConfig.xml";
    otSource->processing=SoOpenTrackerSource::TIME;
    otSource->interval=SbTime(0.01f);
	root->addChild(otSource);
	
    // test SoTrakEngine
    SoTrakEngine *tre=new SoTrakEngine;
 
    tre->key.set1Value(0,"bla");
    tre->value.set1Value(0,"hello");

    SoTransform *tran=new SoTransform;
    
    tran->translation.connectFrom(&tre->translation);
    tran->rotation.connectFrom(&tre->rotation);

    SoSeparator *treRoot=new SoSeparator;

	treRoot->addChild(tran);
	treRoot->addChild(new SoCube);
    root->addChild(treRoot);

    // test SoTrackedArtifactKit
    SoTrackedArtifactKit *trak=new SoTrackedArtifactKit;
    
    trak->key.set1Value(0,"blabla");
    trak->value.set1Value(0,"hi");

    trak->setGeometry(new SoCone);

    SoSeparator *trakRoot=new SoSeparator;
    
    trakRoot->addChild(trak);
    root->addChild(trakRoot);

	SoWinExaminerViewer *viewer = new SoWinExaminerViewer(myWindow);
	viewer->setBackgroundColor(SbColor(0,0,1));
	viewer->setSceneGraph(root);
	viewer->show();
	   
	SoWin::show(myWindow); // Display main window
	SoWin::mainLoop(); // Main Inventor event loop

	return 0;
}

